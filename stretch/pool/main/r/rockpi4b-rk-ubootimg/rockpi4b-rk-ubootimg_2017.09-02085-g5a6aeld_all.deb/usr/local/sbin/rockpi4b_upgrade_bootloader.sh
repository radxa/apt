#!/bin/bash

set -eo pipefail

if [[ "$(id -u)" -ne "0" ]]; then
    echo "This script requires root."
    exit 1
fi

if dpkg -s "rockpi4b-rk-ubootimg" &>/dev/null; then
    BOARD=rockpi4b
    LOADER_NAME=rockpi4b-rk-uboot_arm64
else
    exit "Unknown package installed."
    exit 1
fi

LOADER_BKP="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}_bkp.img"
LOADER="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}.img"
if [[ ! -f "$LOADER" ]]; then
    echo "Missing board bootloader image: $LOADER"
    exit 1
fi

echo "Doing this will overwrite bootloader stored on your boot device. it might break your system."
echo "If this happens you will have to manually fix that outside of your ROCK Pi 4."
echo ""

if ! grep -qi "$BOARD" /proc/device-tree/compatible; then
    echo "You are currently running on different board:"
    cat /proc/device-tree/model
    echo ""
    echo "It may brick your device or the system unless"
    echo "you know what are you doing."
    echo ""
fi

while true; do
    echo "Type YES to continue or Ctrl-C to abort."
    read CONFIRM
    if [[ "$CONFIRM" == "YES" ]]; then
        break
    fi
done

if ! debsums -s "${BOARD}-rk-ubootimg"; then
    echo "Verification of '${BOARD}-rk-ubootimg' failed."
    echo "Your disk might have got corrupted."
    exit 1
fi

MNT_DEV=$(findmnt /boot -n -o SOURCE)


case $MNT_DEV in
    /dev/mmcblk*p4|/dev/sd*p4|/dev/mapper/loop*p4|/dev/mapper/nvme*p4)
        dd if="${MNT_DEV/p4/p2}" of="${LOADER_BKP}"
        ;;

    *)
        echo "Cannot detect boot device ($MNT_DEV)."
        exit 1
        ;;
esac

sync
sleep 2

case $MNT_DEV in
    /dev/mmcblk*p4|/dev/sd*p4|/dev/mapper/loop*p4|/dev/mapper/nvme*p4)
        dd if=$LOADER of="${MNT_DEV/p4/p2}"
        ;;

    *)
        echo "Cannot detect boot device ($MNT_DEV)."
        exit 1
        ;;
esac

sync

echo Done.
