#wrapper for the C module
from _blueman import *
