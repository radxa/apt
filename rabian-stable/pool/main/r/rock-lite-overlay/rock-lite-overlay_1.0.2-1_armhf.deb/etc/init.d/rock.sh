#!/bin/sh
### BEGIN INIT INFO
# Provides:          rock.sh
# Required-Start:    hostname $local_fs
# Required-Stop:
# Should-Start:
# Default-Start:     1 2 3 4 5
# Default-Stop:
# Short-Description: Some init for radxa rock
# Description:       This script do some init such as resize2fs at first time booting
### END INIT INFO

PATH=/sbin:/usr/sbin:/bin:/usr/bin
. /lib/init/vars.sh

resizefs () {
START_SECTOR=`cat /sys/block/mmcblk0/mmcblk0p1/start`
fdisk /dev/mmcblk0  << EOF
d
n
p
1
$START_SECTOR

w

EOF
echo "=========resize2fs  /dev/mmcblk0p1==========="
resize2fs -p /dev/mmcblk0p1
}

do_start () {
	if [ -e /etc/firstboot ];then
		echo "======Expanding the rootfs..."
		resizefs

		rm -f /etc/firstboot
	fi
	#enable HDMI wlan0  if not detected at booting time
	echo 1 > /sys/class/display/display0.HDMI/enable
	echo 1 > /sys/class/rkwifi/driver
	echo 1 > /sys/class/rfkill/rfkill0/state
}

case "$1" in
  start|"")
	do_start
	;;
  restart|reload|force-reload)
	echo "Error: argument '$1' not supported" >&2
	exit 3
	;;
  stop)
	echo "Error: argument '$1' not supported" >&2
	exit 3
	;;
  status)
	echo "Error: argument '$1' not supported" >&2
	exit 3
	;;
  *)
	echo "Usage: rock-overlay [start|stop|status]" >&2
	exit 3
	;;
esac
