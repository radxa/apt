#!/bin/sh
### BEGIN INIT INFO
# Provides:          rock.sh
# Required-Start:    hostname $local_fs
# Required-Stop:
# Should-Start:
# Default-Start:     1 2 3 4 5
# Default-Stop:
# Short-Description: Some init for radxa rock
# Description:       This script do some init such as resize2fs at first time booting
### END INIT INFO

PATH=/sbin:/usr/sbin:/bin:/usr/bin
. /lib/init/vars.sh

do_start () {
	if [ -e /etc/firstboot ];then
		echo "======Expanding the rootfs..."
		resize2fs /dev/block/mtd/by-name/linuxroot

		rm -f /firstboot
	fi

}

case "$1" in
  start|"")
	do_start
	;;
  restart|reload|force-reload)
	echo "Error: argument '$1' not supported" >&2
	exit 3
	;;
  stop)
	echo "Error: argument '$1' not supported" >&2
	exit 3
	;;
  status)
	echo "Error: argument '$1' not supported" >&2
	exit 3
	;;
  *)
	echo "Usage: rock-overlay [start|stop|status]" >&2
	exit 3
	;;
esac
