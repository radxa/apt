#!/bin/bash

set -eo pipefail

if [[ "$(id -u)" -ne "0" ]]; then
    echo "This script requires root."
    exit 1
fi

BOARD=rockpis
LOADER_NAME=rockpis-rk-uboot
LOADER_BKP="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}_bkp.img"
LOADER="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}.img"
if [[ ! -f "$LOADER" ]]; then
    echo "Missing board bootloader image: $LOADER"
    exit 1
fi

echo "You are currently running on board:"
cat /proc/device-tree/model
echo " "

upgrade_bootlader_on_usd()
{
    echo " "
    echo "Will upgrade bootloader on uSD card."
    if findmnt / -n -o SOURCE | grep -qi "mmc" ;then
        echo "Boot device, uSD card, is found. Would you like to upgrade bootloader on it?"
        echo "If yes, type "Y/y". If no, type "N/n"."

        while true; do
            read CONFIRM
            if [[ "$CONFIRM" == "Y" ]] || [[ "$CONFIRM" == "y" ]]; then
                MNT_DEV=$(findmnt / -n -o SOURCE)
                echo "Backup bootloader on boot device (${MNT_DEV/p5/p2})."
                dd if="${MNT_DEV/p5/p2}" of="${LOADER_BKP}"
                sync
                sleep 2

                echo "Overwrite bootloader to boot device (${MNT_DEV/p5/p2})."
                dd if=$LOADER of="${MNT_DEV/p5/p2}"
                sync
                sleep 2
                break
            elif [[ "$CONFIRM" == "N" ]] || [[ "$CONFIRM" == "n" ]]; then
                echo "Do not overwrite bootloader to uSD card."
                echo "You can upgrade it by executing /usr/local/sbin/rockpis_upgrade_bootloader.sh later."
                break
            else
                echo "Unrecognized answer. Please type correct answer again."
            fi
        done
    else
        echo "Boot device, uSD card, is not found."
    fi
}

upgrade_bootlader_on_usd
sync
echo Done.
