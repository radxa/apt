#!/bin/bash

set -eo pipefail

if [[ "$(id -u)" -ne "0" ]]; then
    echo "This script requires root."
    exit 1
fi

BOARD=rockpi4a
LOADER_NAME=rockpi4a-rk-uboot
LOADER_BKP="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}_bkp.img"
LOADER="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}.img"
LOADER_ON_SPI="/usr/lib/u-boot-${BOARD}/spi/uboot-trust-spi.img"
if [[ ! -f "$LOADER" ]]; then
    echo "Missing board bootloader image: $LOADER"
    exit 1
fi
if [[ ! -f "$LOADER_ON_SPI" ]]; then
    echo "Missing board bootloader image: $LOADER_ON_SPI"
    exit 1
fi

echo "You are currently running on board:"
cat /proc/device-tree/model
echo " "
echo "There will be two steps that you have to confirm. One is upgrading bootloader on SPI Flash."
echo "The other is upgrading bootloader on eMMC or uSD card."

MNT_DEV=$(findmnt / -n -o SOURCE)

upgrade_bootloader_on_spi_flash()
{
    echo " "
    echo "Step one: upgrade bootloader on SPI Flash"
    local MTD
    if MTD=$(grep \"$1\" /proc/mtd | cut -d: -f1) ; then
        echo "One boot device, SPI Flash, is found, would you like to upgrade bootloader on it?"
        echo "The installation would cost about seven minutes."
        echo "If yes, type "Y/y". If no, type "N/n"."

        while true; do
            read CONFIRM
            if [[ "$CONFIRM" == "Y" ]] || [[ "$CONFIRM" == "y" ]]; then
                echo "Overwrite bootloader to SPI Flash device."
                echo "Writing /dev/$MTD with content of $2"
                flash_erase "/dev/$MTD" 0 0
                nandwrite "/dev/$MTD" < "$2"
                break
            elif [[ "$CONFIRM" == "N" ]] || [[ "$CONFIRM" == "n" ]]; then
                echo "Do not overewrite bootloader to SPI Flash device."
                echo "You can upgrade it by executing /usr/local/sbin/rockpi4a_upgrade_bootloader.sh later."
                break
            else
                echo "Unrecognized answer. Please type correct answer again."
            fi
        done
    else
        echo "Boot device, SPI Flash, is not found. Make sure there is one SPI Flash on board."
        echo "You can install package rockpi4-dtbo later manually and uncomment three lines in file /boot/hw_intfc.conf."
        echo "intfc:uart4=off"
        echo "intfc:spi1=on"
        echo "intfc:dtoverlay=spi1-flash"
        echo "After restarting the Pi, execute command, /usr/local/sbin/rockpi4a_upgrade_bootloader.sh."
    fi
}

upgrade_bootlader_on_usd_or_emmc()
{
    echo " "
    echo "Step two: upgrade bootloader on uSD card or eMMC"
    if findmnt / -n -o SOURCE | grep -qi "mmc" ;then
        echo "Boot device, uSD card or eMMC, is found. Would you like to upgrade bootloader on it?"
        echo "If yes, type "Y/y". If no, type "N/n"."

        while true; do
            read CONFIRM
            if [[ "$CONFIRM" == "Y" ]] || [[ "$CONFIRM" == "y" ]]; then
                MNT_DEV=$(findmnt / -n -o SOURCE)
                echo "Backup bootloader on boot device (${MNT_DEV/p5/p2})."
                dd if="${MNT_DEV/p5/p2}" of="${LOADER_BKP}"
                sync
                sleep 2

                echo "Overwrite bootloader to boot device (${MNT_DEV/p5/p2})."
                dd if=$LOADER of="${MNT_DEV/p5/p2}"
                sync
                sleep 2
                break
            elif [[ "$CONFIRM" == "N" ]] || [[ "$CONFIRM" == "n" ]]; then
                echo "Do not overwrite bootloader to uSD card or eMMC device."
                echo "You can upgrade it by executing /usr/local/sbin/rockpi4a_upgrade_bootloader.sh later."
                break
            else
                echo "Unrecognized answer. Please type correct answer again."
            fi
        done
    else
        echo "Boot device, uSD card or eMMC, is not found."
    fi
}

upgrade_bootloader_on_spi_flash loader "$LOADER_ON_SPI"
upgrade_bootlader_on_usd_or_emmc
sync
echo Done.
