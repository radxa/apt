This package provides Broadcom WiFi and Bluetooth chip firmware.

chip list:
* ap6236
* ap6255
* ap6256
* ap6356
* ap6398s
