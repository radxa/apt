#!/usr/bin/env python

# Author: Brendan Le Foll <brendan.le.foll@intel.com>
# Copyright (c) 2014 Intel Corporation.
#
# SPDX-License-Identifier: MIT
#
# Example Usage: Reads integer and float value from ADC

import mraa
import time

print(mraa.getVersion())

# initialise AIO
x = mraa.Aio(0)

while True:
    # read integer value
    print(x.read())

    time.sleep(1)

    # read float value
    print("%.5f" % x.readFloat())
