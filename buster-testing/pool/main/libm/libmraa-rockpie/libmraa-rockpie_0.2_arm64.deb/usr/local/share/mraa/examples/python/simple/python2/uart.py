#!/usr/bin/env python

# Author: Manivannan Sadhasivam <manivannan.sadhasivam@linaro.org>
# Copyright (c) 2018 Linaro Ltd.
#
# SPDX-License-Identifier: MIT
#
# Example Usage: Sends data through UART

import mraa
import time
import sys

# serial port
port = "/dev/ttyS1"

data = 'Hello Mraa!'

# initialise UART
uart = mraa.Uart(port)

# Setting baud rate
uart.setBaudRate(1500000)

# send data through UART
uart.write(bytearray(data, 'utf-8'))

rxbuf=1
while 1: 
    # wait read data
    print(uart.read(rxbuf))
