#!/usr/bin/env python

# Author: Brendan Le Foll <brendan.le.foll@intel.com>
# Copyright (c) 2014 Intel Corporation.
#
# SPDX-License-Identifier: MIT
#
# Example Usage: Changes the Grove-LCD RGB backlight to a nice shade of purple

import mraa

n=1

# initialise I2C
x = mraa.I2c(0)
x.address(0x50)

# write data to register 
x.writeReg(0x08, 0xAA)

while n<10000:
    n += 1;

# read data from register
print(x.readReg(0x08))

