#!/bin/bash

[ ! -f /boot/uEnv.txt ] && echo "There is no /boot/uEnv.txt. Exit." && exit 0

# get kernel latest version
export KERNEL_VERSION=$(linux-version list | linux-version sort --reverse | awk 'NR==1 {print}')

# get initrd image size
TMP=$(stat /boot/initrd.img-${KERNEL_VERSION} | grep "Size" | cut -d ":" -f2 | cut -d " " -f2)
INITRDSIZE=$(echo "obase=16;$TMP"|bc)
INITRDSIZE=$(echo ${INITRDSIZE,,})

update_uenv() {
    echo $INITRDSIZE
    echo $KERNEL_VERSION
    echo "initrdsize=0x${INITRDSIZE}" >> /boot/uEnv.txt
    echo "kernelversion=${KERNEL_VERSION}" >> /boot/uEnv.txt
    echo "initrdimg=initrd.img-${KERNEL_VERSION}" >> /boot/uEnv.txt
    echo "kernelimg=vmlinuz-${KERNEL_VERSION}" >> /boot/uEnv.txt
}
update_uenv

