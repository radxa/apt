#!/bin/bash

TIMEOUT=""
DEFAULT=""

APPEND="earlyprintk"
APPEND="$APPEND console=ttyFIQ0,1500000n8"
APPEND="$APPEND rw"
APPEND="$APPEND init=/sbin/init"

set -eo pipefail

. /etc/default/extlinux

echo "Creating new extlinux.conf..." 1>&2

mkdir -p /boot/extlinux/
exec 1> /boot/extlinux/extlinux.conf.new

echo "timeout ${TIMEOUT:-10}"
echo "menu title select kernel"
[[ -n "$DEFAULT" ]] && echo "default $DEFAULT"
echo ""

emit_kernel() {
  local VERSION="$1"
  local APPEND="$2"
  local NAME="$3"

  echo "label kernel-$VERSION$NAME"
  echo "    kernel /vmlinuz-$VERSION"
#  if [[ -f "/boot/initrd.img-$VERSION" ]]; then
#    echo "    initrd /boot/initrd.img-$VERSION"
#  fi

  if [[ -f "/boot/dtb-$VERSION" ]]; then
    echo "    fdt /dtb-$VERSION"
  else
    if [[ ! -d "/boot/dtbs/$VERSION" ]]; then
      mkdir -p /boot/dtbs
      cp -au "/usr/lib/linux-image-$VERSION" "/boot/dtbs/$VERSION"
    fi
    echo "    devicetreedir /dtbs/$VERSION"
  fi

  echo "    append $APPEND"
  echo ""
}

linux-version list | linux-version sort --reverse | while read VERSION; do
  emit_kernel "$VERSION" "$APPEND"
done

echo "label kernel-4.4"
echo "    kernel /Image"
echo "    fdt /rockpi-4b-linux.dtb"
echo "    append $APPEND"

exec 1<&-

echo "Installing new extlinux.conf..." 1>&2
mv /boot/extlinux/extlinux.conf.new /boot/extlinux/extlinux.conf
