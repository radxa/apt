export GST_GL_API=gles2
export GST_GL_PLATFORM=egl
