#!/bin/bash

#Check if script is being run as root
if [ "$(id -u)" != "0" ]; then
    echo "This script must be run as root" 1>&2
    exit 1
fi

turn_on_sy6702() {
    echo 1 | sudo tee /sys/class/gpio/gpio133/value
}

turn_off_sy6702() {
    echo 0 | sudo tee /sys/class/gpio/gpio133/value
}

set_pwm() {
    local PWM_NAME="$1"
    local PERIOD="$2"
    local DUTY_CYCLE="$3"
    local POLARITY="$4"
    local IS_ENABLE="$5"

    if [[ "$PWM_NAME" == "pwm0" ]] ; then
        echo $PERIOD | sudo tee /sys/class/pwm/pwmchip0/pwm0/period
        echo $DUTY_CYCLE | sudo tee /sys/class/pwm/pwmchip0/pwm0/duty_cycle
        echo $POLARITY | sudo tee /sys/class/pwm/pwmchip0/pwm0/polarity
        echo $IS_ENABLE | sudo tee /sys/class/pwm/pwmchip0/pwm0/enable
    elif [[ "$PWM_NAME" == "pwm1" ]] ; then
        echo $PERIOD | sudo tee /sys/class/pwm/pwmchip1/pwm0/period
        echo $DUTY_CYCLE | sudo tee /sys/class/pwm/pwmchip1/pwm0/duty_cycle
        echo $POLARITY | sudo tee /sys/class/pwm/pwmchip1/pwm0/polarity
        echo $IS_ENABLE | sudo tee /sys/class/pwm/pwmchip1/pwm0/enable
    fi
}

initial_pins() {
    local PWMCHIP="$1"
    if [[ "$PWMCHIP" == "pwm0" ]]; then
        echo 150 | sudo tee /sys/class/gpio/export
        echo out | sudo tee /sys/class/gpio/gpio150/direction
        echo 0 | sudo tee /sys/class/gpio/gpio150/value

        echo 0 | sudo tee /sys/class/pwm/pwmchip0/export
        set_pwm "pwm0" "10000000" "9999000" "normal" "0"
    elif [[ "$PWMCHIP" == "pwm1" ]]; then
        echo 146 | sudo tee /sys/class/gpio/export
        echo out | sudo tee /sys/class/gpio/gpio146/direction
        echo 0 | sudo tee /sys/class/gpio/gpio146/value

        echo 0 | sudo tee /sys/class/pwm/pwmchip1/export
        set_pwm "pwm1" "10000000" "9999000" "normal" "0"
    fi

    #sy6702 sleep pin
    echo 133 | sudo tee /sys/class/gpio/export
    echo out | sudo tee /sys/class/gpio/gpio133/direction
    echo 0 | sudo tee /sys/class/gpio/gpio133/value
}

unexport_pins() {
    local PWMCHIP="$1"
    if [[ "$PWMCHIP" == "pwm0" ]]; then
        echo 146 | sudo tee /sys/class/gpio/unexport
        echo 0 | sudo tee /sys/class/pwm/pwmchip0/unexport
    elif [[ "$PWMCHIP" == "pwm1" ]]; then
        echo 150 | sudo tee /sys/class/gpio/unexport
        echo 0 | sudo tee /sys/class/pwm/pwmchip1/unexport
    fi

    #sy6702 sleep pin
    echo 133 | sudo tee /sys/class/gpio/unexport
}

#initial
#enable pwm0, pwm1 (/boot/hw_intfc.conf)
initial_pins "pwm1"

ret=
while true
do
    sudo python2.7 "/etc/init.d/poe-ntc-adc-value.py"
    sleep 5
    ret=$(cat "/tmp/poe-adc-log.txt")
    if [[ "$ret" == "1" ]]; then
        echo "step 1"
	turn_on_sy6702
        set_pwm "pwm1" "10000000" "9999000" "normal" "1"
    elif [[ "$ret" == "2" ]]; then
        echo "step 2"
	turn_on_sy6702
        set_pwm "pwm1" "10000000" "8000000" "normal" "1"
    elif [[ "$ret" == "3" ]]; then
        echo "step 3"
	turn_on_sy6702
        set_pwm "pwm1" "10000000" "5000000" "normal" "1"
    elif [[ "$ret" == "0" ]]; then
        echo "step 0"
	turn_off_sy6702
        set_pwm "pwm1" "10000000" "0" "normal" "0"
    fi
    echo "testing..."
done

#exit
set_pwm "pwm1" "0" "0" "normal" "0"
unexport_pins "pwm1"
echo "Done."
