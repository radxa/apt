#!/usr/bin/env python
# /home/rock/get-adc.py

import mraa
import time
import os
import sys

os.system('touch /tmp/poe-adc-log.txt')

adc_in0 = mraa.Aio(0)
i = 10
sum = 0
result = 0
while i:
    time.sleep(0.5)
    result = adc_in0.read() + result
    i -= 1

result = result/10
print(result)

if (result < 800):
    os.system('echo 1 > /tmp/poe-adc-log.txt')
elif (result >= 800 and result < 860):
     os.system('echo 2 > /tmp/poe-adc-log.txt') 
elif (result >= 860 and result < 900):
    os.system('echo 3 > /tmp/poe-adc-log.txt') 
elif (result >= 900):
    os.system('echo 0 > /tmp/poe-adc-log.txt')
