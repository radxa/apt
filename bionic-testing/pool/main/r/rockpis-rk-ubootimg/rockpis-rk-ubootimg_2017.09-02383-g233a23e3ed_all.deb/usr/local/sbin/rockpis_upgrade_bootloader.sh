#!/bin/bash

set -eo pipefail

if [[ "$(id -u)" -ne "0" ]]; then
    echo "This script requires root."
    exit 1
fi

BOARD=rockpis
LOADER_NAME=rockpis-rk-uboot
LOADER_BKP="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}_bkp.img"
LOADER="/usr/lib/u-boot-${BOARD}/${LOADER_NAME}.img"
if [[ ! -f "$LOADER" ]]; then
    echo "Missing board bootloader image: $LOADER"
    exit 1
fi

echo "You are currently running on board:"
cat /proc/device-tree/model
echo " "

# find root device
ROOT_DEVICE=$(findmnt --noheadings --output=SOURCE / | cut -d'[' -f1)
# prune root device (for example UUID)
ROOT_DEVICE=$(realpath ${ROOT_DEVICE})
# find the block device
DEVICE=$(udevadm info --query=path --name=${ROOT_DEVICE} | awk -F'/' '{print $(NF-1)}')
DEVICE="/dev/${DEVICE}"

upgrade_bootlader_on_usd_or_sdnand()
{
    echo "Looking for boot device ..."
    if findmnt / -n -o SOURCE | grep -qi "mmc" ;then
        if findmnt / -n -o SOURCE | grep -qi "mmcblk0" ;then
            echo "Current boot device is uSD card."
        elif findmnt / -n -o SOURCE | grep -qi "mmcblk1" ;then
            echo "Current boot device is SD Nand."
        fi

        echo "Would you like to upgrade bootloader on it?"
        echo "If yes, type "Y/y". If no, type "N/n"."

        while true; do
            read CONFIRM
            if [[ "$CONFIRM" == "Y" ]] || [[ "$CONFIRM" == "y" ]]; then
                echo "Backup bootloader on boot device."
                dd if="${DEVICE}" of="${LOADER_BKP}" bs=512 skip=16384 count=2048
                sync
                sync
                sleep 2

                echo "Overwrite bootloader to boot device."
                dd if="$LOADER" of="${DEVICE}" bs=512 seek=16384
                sync
                sync
                sleep 2
                break
            elif [[ "$CONFIRM" == "N" ]] || [[ "$CONFIRM" == "n" ]]; then
                echo "Do not overwrite bootloader to boot device."
                echo "You can upgrade it by executing /usr/local/sbin/rockpis_upgrade_bootloader.sh later."
                break
            else
                echo "Unrecognized answer. Please type correct answer again."
            fi
        done
    else
        echo "Boot device, uSD card or SD Nand, is not found."
    fi
}

upgrade_bootlader_on_usd_or_sdnand
echo Done.
